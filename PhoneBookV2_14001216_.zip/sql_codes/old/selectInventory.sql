select * from inventory;
go
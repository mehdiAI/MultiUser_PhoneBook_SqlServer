CREATE PROCEDURE search_one (

)
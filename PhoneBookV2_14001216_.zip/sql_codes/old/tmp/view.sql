
select distinct * from [dbo].[all]
where first_name like N'م%'
order by first_name;

select distinct * from [dbo].[all]
where first_name like 'Alex2'

select distinct * from [dbo].[all]
where id>1000


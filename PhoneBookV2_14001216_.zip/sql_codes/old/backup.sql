
backup database PhoneBook
to disk = '/var/opt/mssql/data/PB14001126.bak'